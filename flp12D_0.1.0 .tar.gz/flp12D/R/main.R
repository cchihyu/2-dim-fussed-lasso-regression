#' create matrix D in 1 dimension fussed lasso problem
#' @param dim length of data
#' @param vec panelty vector
#' @return matrix D
#' @export
#' @examples
#' create_1D(12,c(1,-2,1))
#' create_1D(100,c(1,-1))
create_1D<-function(dim,vec){
    lef<-c()
    rig<-matrix(0,dim-length(vec)+1,length(vec)-1)
    D<-matrix(0,dim-length(vec)+1,dim)
    for (i in 1:length(vec)) {
        rig<-matrix(0,dim-length(vec)+1,length(vec)-i)
        D=D+cbind(lef,vec[i]*diag(dim-length(vec)+1),rig)
        lef<-cbind(lef,rep(0,dim-length(vec)+1))
    }
    return(D)
}

#' preform 1 dimension fussed lasso problem
#' @param vec panelty vector
#' @param y input data
#' @param tao coefficient of panelty
#' @param rho coefficient of second order expension
#' @param iter maximum iteration
#' @param error maximum torrence of error
#' @return beta, lamda, loss, delta, loss, error
#' @export
#' @examples
#' flp_1D(c(1,-1),data,1,0.01,1000,10^-7)
flp_1D<-function(vec,y,tau,rho,iter,error){
    n<-length(y)
    D<-create_1D(n,vec)
    ID<-solve(diag(n)+rho*t(D)%*%D)
    beta<-rep(mean(y),n)
    num_lim<-nrow(D)
    delta<-matrix(0,1,num_lim)
    lambda<-matrix(0,1,num_lim)
    err<-c()
    loss<-c()
    soft_threshold <- function(a, threshold){
        as.vector(sign(a)*max(0, abs(a)-threshold))
    }
    for (i in 2:(iter+1)) {
        b<-ID%*%(y+rho*t(D)%*%(delta[i-1,]-lambda[i-1,]/rho))
        d<-soft_threshold(D%*%b+lambda[i-1,]/rho, tau/rho)
        l<-lambda[i-1,]+rho*(D%*%b-d)
        beta<-rbind(beta,as.vector(b))
        delta<-rbind(delta,as.vector(d))
        lambda<-rbind(lambda,as.vector(l))
        e<-max(abs(beta[i]- beta[i-1]))
        los<-0.5*sum((y-b)^2)+tau*sum(abs(D%*%b))
        err[i-1]=e
        loss[i-1]=los
        if(e<error)
            break
    }
    return(list(beta=beta,lambda=lambda,delta=delta,loss=loss,err=err))
}

#' create matrix D in 2 dimension fussed lasso problem
#' @param dim length of data
#' @param UD panelty vector in x axis
#' @param LR panelty vector in y axis
#' @return matrix D
#' @export
#' @examples
#' create_2D(12,c(1,-2,1))
#' create_2D(100,c(1,-1))
create_2D<-function(dim,UD,LR){
    n<-dim[1]
    r<-dim[2]
    c<-dim[3]
    D<-c()
    D1<-matrix(0,(r-length(UD)+1)*c,n)
    IND=0
    for (i in 1:c) {
        start=i
        for (j in 1:(r-length(UD)+1)) {
            IND=IND+1
            for (k in 1:length(UD)) {
                D1[IND,start+(k-1)*c]=UD[k]
            }
            start=start+c
        }
    }
    D2<-c()
    dup<-create_1D(c,LR)
    lef<-c()
    rig<-matrix(0,c-length(LR)+1,n)
    for (i in 1:r) {
        rig<-rig[,-c(1:c)]
        lr<-cbind(lef,dup,rig)
        lef<-cbind(lef,matrix(0,c-length(LR)+1,c))
        D2<-rbind(D2,lr)
    }
    return(rbind(D1,D2))
}

#' preform 2 dimension fussed lasso problem
#' @param UD panelty vector on x axis
#' @param LR panelty vector on y axis
#' @param r row of image
#' @param c column of image
#' @param y input data
#' @param tao coefficient of panelty
#' @param rho coefficient of second order expension
#' @param iter maximum iteration
#' @param error maximum torrence of error
#' @return beta, lamda, loss, delta, loss, error
#' @export
#' @examples
#' flp_2D(c(1,-1),c(1,-2,1),20,20,data,1,0.01,1000,10^-7)
flp_2D<-function(UD,LR,r,c,y,tau,rho,iter,error){
    n<-length(y)
    D<-create_2D(c(n,r,c),UD,LR)
    ID<-solve(diag(n)+rho*t(D)%*%D)
    beta<-rep(mean(y),n)
    num_lim<-nrow(D)
    delta<-matrix(0,1,num_lim)
    lambda<-matrix(0,1,num_lim)
    err<-c()
    loss<-c()
    soft_threshold <- function(a, threshold){
        as.vector(sign(a)*max(0, abs(a)-threshold))
    }
    for (i in 2:(iter+1)) {
        b<-ID%*%(y+rho*t(D)%*%(delta[i-1,]-lambda[i-1,]/rho))
        d<-soft_threshold(D%*%b+lambda[i-1,]/rho, tau/rho)
        l<-lambda[i-1,]+rho*(D%*%b-d)
        beta<-rbind(beta,as.vector(b))
        delta<-rbind(delta,as.vector(d))
        lambda<-rbind(lambda,as.vector(l))
        e<-max(abs(beta[i]- beta[i-1]))
        los<-0.5*sum((y-b)^2)+tau*sum(abs(D%*%b))
        err[i-1]=e
        loss[i-1]=los
        if(e<error)
            break
    }
    return(list(beta=beta,lambda=lambda,delta=delta,loss=loss,err=err))
}
